# Majestic Gutenberg

This is a Wordpress plugin that holds a bunch of custom Gutenberg blocks.
